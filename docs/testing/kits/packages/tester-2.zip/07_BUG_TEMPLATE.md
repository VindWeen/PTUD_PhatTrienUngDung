# Bug log người 2

Mã: BUG-T2-001
Môi trường: ENV-T2
Ca liên quan:
Tài khoản / trạng thái trước:
Các bước tái hiện:
1.
2.
Mong đợi:
Thực tế:
Ảnh/video/file:
Mức độ:
Ngày / người test:
Kết quả test lại:
