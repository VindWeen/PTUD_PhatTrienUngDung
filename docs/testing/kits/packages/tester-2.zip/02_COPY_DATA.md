# Dữ liệu mẫu để copy theo form

Ngày mẫu 19/10/2026. Nếu test ngày khác: đổi ngày quyết định và lịch thành ngày phù hợp; giữ thứ tự thời gian và nhãn mô phỏng. Kỳ SCN chọn theo ngày seed thực tế.

## Thông tin khi thêm minh chứng / phiên bản

[File để copy](copy/evidence.txt)

| Trường | Giá trị |
| --- | --- |
| Tên minh chứng ban đầu | UI-T2-R01-EVIDENCE / Minh chứng mô phỏng V1 |
| Mô tả | Tệp mô phỏng dùng kiểm upload, tải về và lịch sử phiên bản. |
| File ban đầu | uploads/valid/evidence-v1.pdf |
| Ghi chú phiên bản mới | V2: bổ sung nội dung để đối chiếu; khác nội dung và SHA của V1. |
| File phiên bản mới | uploads/valid/evidence-v2.pdf |

## Đăng nhập và chuyển vai trò

[File để copy](copy/auth.txt)

| Trường | Giá trị |
| --- | --- |
| Mật khẩu 10 tài khoản SCN | demo1234 |
| Tài khoản dùng | an.nv / bich.tt / duc.pm / cuong.lh / records.demo / council.demo / council.other / linh.pharm / rep.expired / locked.demo |
| Mật khẩu sai để thử | Wrong@2026 |
| Tài khoản không tồn tại | not.exists.t2 |
| Lưu ý | locked.demo cố ý bị khóa; rep.expired có role nhưng phân công đã hết hạn. Chuyển role bằng đăng xuất hoặc profile trình duyệt riêng. |

## Nháp thành tích dùng riêng

[File để copy](copy/achievement.txt)

| Trường | Giá trị |
| --- | --- |
| Tên thành tích | UI-T2-R01-ACH-01 / Hồ sơ thử nghiệm cá nhân [MÔ PHỎNG] |
| Chủ thể | Cá nhân / Nguyễn Văn An |
| Loại thành tích | Bài báo quốc tế ISI/Scopus Q1 |
| Mô tả | Dữ liệu thử nghiệm giao diện. Chỉ dùng kiểm luồng kê khai, minh chứng và xét duyệt; không xác nhận thành tích thực tế. |
| Vai trò đóng góp | Tác giả chính |
| Ngày bắt đầu | 2026-09-29 |
| Ngày kết thúc | 2026-10-14 |
| Năm ghi nhận | 2026 |
| Năm học | 2026-2027 |
| File chọn | uploads/valid/evidence-v1.pdf |

## Ý kiến và lý do mẫu

[File để copy](copy/reasons.txt)

| Trường | Giá trị |
| --- | --- |
| Yêu cầu bổ sung | Bổ sung vai trò đóng góp và tải lại minh chứng có nội dung phiên bản V2 để đối chiếu. |
| Nội dung bổ sung | Đã bổ sung vai trò tác giả chính, tổng hợp dữ liệu và kiểm tra kết quả. Minh chứng V2 được đính kèm. |
| Xác nhận thành tích | Đã kiểm tra nội dung và minh chứng của hồ sơ mô phỏng, thông tin khớp với dữ liệu thử nghiệm. |
| Từ chối | Minh chứng thử nghiệm không khớp nội dung kê khai trong ca kiểm nhánh từ chối. |
| Rút/hủy | Chủ hồ sơ rút kê khai để kiểm tra lịch sử và trạng thái hủy. |
| Thu hồi | Phát hiện sai nội dung trong hồ sơ mô phỏng; thu hồi để kiểm tra báo cáo và bản thay thế. |
| Chuyển Hội đồng | Đơn vị đã đối chiếu thành tích nguồn và minh chứng. Chuyển Hội đồng rà soát hồ sơ mô phỏng. |
| Phân công | Phân công council.demo xử lý hồ sơ mô phỏng trong phạm vi CNTT. |
| Ghi ý kiến Hội đồng | Hồ sơ mô phỏng có nguồn và minh chứng đọc được; cần đối chiếu tiêu chí áp dụng trước kết luận. |
| Đề nghị | Đề nghị xử lý khen thưởng trong kịch bản thử nghiệm; chưa phải quyết định trao thưởng. |
| Không đề nghị | Chưa đáp ứng yêu cầu của nhánh kiểm thử; lưu lý do không đề nghị. |
| File bổ sung | uploads/valid/evidence-v2.pdf |

## Đề nghị cá nhân mới

[File để copy](copy/proposal.txt)

| Trường | Giá trị |
| --- | --- |
| Chủ thể | Cá nhân / Nguyễn Văn An |
| Kỳ xét | SCN / Kỳ xét thưởng đang mở - MÔ PHỎNG (SCN-OPEN-2026) |
| Loại khen thưởng | Chiến sĩ thi đua cơ sở |
| Thành tích chọn | SCN-A04 |
| Mục đích đề nghị | UI-T2-R01-APP-NEW / Đề nghị xét khen thưởng MÔ PHỎNG để kiểm thử UI. |
| Lưu ý | Chọn hồ sơ bằng tên; chỉ dùng nguồn đã xác nhận của đúng chủ thể. |

## Đề nghị / thành tích tập thể

[File để copy](copy/collective.txt)

| Trường | Giá trị |
| --- | --- |
| Chủ thể | Tập thể / Bộ môn Kỹ thuật Phần mềm |
| Kỳ xét | SCN / Kỳ xét thưởng đang mở - MÔ PHỎNG (SCN-OPEN-2026) |
| Loại khen thưởng | Tập thể Lao động xuất sắc |
| Thành tích chọn | SCN-T02 |
| Mục đích đề nghị | UI-T2-R01-APP-UNIT / Đề nghị xét khen thưởng MÔ PHỎNG để kiểm thử UI. |
| Lưu ý | Chọn hồ sơ bằng tên; chỉ dùng nguồn đã xác nhận của đúng chủ thể. |
| Tài khoản kê khai | cuong.lh |
| Tên thành tích nếu cần tự tạo | UI-T2-R01-UNIT-ACH / Sáng chế tập thể mô phỏng |
| Loại thành tích | Bằng độc quyền sáng chế |
| Lưu ý phạm vi | Cường đại diện KTPM, không phải KHMT hoặc toàn Khoa CNTT. |

## Quyết định và sổ riêng

[File để copy](copy/decision.txt)

| Trường | Giá trị |
| --- | --- |
| Số quyết định | UI-T2-R01-AWD-NEW-2026 |
| Ngày quyết định | 2026-10-19 |
| Cơ quan ban hành | Đơn vị mô phỏng PTUD |
| Tên quyết định | UI-T2-R01-AWD-NEW / Quyết định thử nghiệm, không có giá trị thực tế |
| Chủ thể ghi sổ | Cá nhân / Nguyễn Văn An |
| Loại khen thưởng | Chiến sĩ thi đua cơ sở |
| Năm ghi nhận | 2026 |
| Nguồn chọn | SCN-A04 (hoặc thành tích riêng đã xác nhận của ca) |
| File quyết định | uploads/valid/decision-demo.pdf |

## Thông tin hồ sơ mẫu

[File để copy](copy/profile.txt)

| Trường | Giá trị |
| --- | --- |
| Số điện thoại | 0900000001 |
| Chức danh | Giảng viên thử nghiệm |
| Học vị | Thạc sĩ |
| Lưu ý | Thông tin giả lập để kiểm lưu; không đổi đơn vị hoặc quyền ở form hồ sơ. |

## Tài khoản chuyên dùng đổi mật khẩu

[File để copy](copy/password.txt)

| Trường | Giá trị |
| --- | --- |
| Tài khoản | ui.t2.password |
| Mật khẩu hiện tại sau seed bổ sung | demo1234 |
| Mật khẩu mới hợp lệ | UiT2@Change2026 |
| Mật khẩu xác nhận sai | UiT2@Mismatch2026 |
| Mật khẩu mới quá ngắn | abc |
| Khôi phục sau ca nếu cần | Đổi lại demo1234 qua UI bằng mật khẩu hiện tại mới; không đổi mật khẩu tài khoản An/Bích. |
| Lưu ý chuẩn bị | Người phụ trách chạy prepareUiTestAccounts.js --tester=2 --apply trên ENV-T2 trước buổi test. Tài khoản có role, hồ sơ giảng viên, phân công KTPM. |

## Lịch riêng để kiểm bàn phím UX-03

[File để copy](copy/keyboard-calendar.txt)

| Trường | Giá trị |
| --- | --- |
| Tiêu đề | UI-T2-R01-UX-KEYBOARD |
| Loại | Công việc |
| Bắt đầu | 2026-10-20T08:00 |
| Kết thúc | 2026-10-20T09:00 |
| Ghi chú | Lịch giả lập cho kiểm Tab/Shift+Tab/Enter/Space/Esc. |

## Sổ riêng để đối chiếu báo cáo trước/sau thu hồi

[File để copy](copy/report-revoke.txt)

| Trường | Giá trị |
| --- | --- |
| Số quyết định | UI-T2-R01-REPORT-REVOKE-2026 |
| Ngày quyết định | 2026-10-19 |
| Cơ quan ban hành | Đơn vị mô phỏng PTUD |
| Tên quyết định | UI-T2-R01-REPORT-REVOKE / Quyết định thử nghiệm, không có giá trị thực tế |
| Chủ thể ghi sổ | Cá nhân / Nguyễn Văn An |
| Loại khen thưởng | Chiến sĩ thi đua cơ sở |
| Năm ghi nhận | 2026 |
| Nguồn chọn | SCN-A04 (hoặc thành tích riêng đã xác nhận của ca) |
| File quyết định | uploads/valid/decision-demo.pdf |

## Chuẩn bị chống bấm lặp

[File để copy](copy/double.txt)

| Trường | Giá trị |
| --- | --- |
| Tên thành tích | UI-T2-R01-DOUBLE-ACH / Hồ sơ kiểm bấm lặp [MÔ PHỎNG] |
| Chủ thể | Cá nhân / Nguyễn Văn An |
| Loại thành tích | Bài báo quốc tế ISI/Scopus Q1 |
| Mô tả | Dữ liệu thử nghiệm giao diện. Chỉ dùng kiểm luồng kê khai, minh chứng và xét duyệt; không xác nhận thành tích thực tế. |
| Vai trò đóng góp | Tác giả chính |
| Ngày bắt đầu | 2026-09-29 |
| Ngày kết thúc | 2026-10-14 |
| Năm ghi nhận | 2026 |
| Năm học | 2026-2027 |
| File chọn | uploads/valid/evidence-v1.pdf |
| Số quyết định sổ dùng bấm lặp | UI-T2-R01-DOUBLE-AWD-2026 |
| Thứ tự chuẩn bị | An tạo nháp và thêm file → thử bấm đôi Lưu/Gửi; Văn thư tự tạo quyết định và sổ nháp có file → thử bấm đôi Ghi nhận. |
| File quyết định | uploads/valid/decision-demo.pdf |

## Chuẩn bị đối chiếu nhiều màn hình

[File để copy](copy/consistency.txt)

| Trường | Giá trị |
| --- | --- |
| Tên thành tích | UI-T2-R01-CONSISTENCY / Hồ sơ kiểm tính nhất quán [MÔ PHỎNG] |
| Chủ thể | Cá nhân / Nguyễn Văn An |
| Loại thành tích | Bài báo quốc tế ISI/Scopus Q1 |
| Mô tả | Dữ liệu thử nghiệm giao diện. Chỉ dùng kiểm luồng kê khai, minh chứng và xét duyệt; không xác nhận thành tích thực tế. |
| Vai trò đóng góp | Tác giả chính |
| Ngày bắt đầu | 2026-09-29 |
| Ngày kết thúc | 2026-10-14 |
| Năm ghi nhận | 2026 |
| Năm học | 2026-2027 |
| File chọn | uploads/valid/evidence-v1.pdf |
| Mục đích đề nghị | UI-T2-R01-CONSISTENCY / Đề nghị đối chiếu nhiều màn hình |
| Thứ tự tự làm | An lưu/thêm file/gửi → Bích xác nhận → An tạo/nộp đề nghị → Bích chuyển Hội đồng → council.demo đọc. Tất cả trong ENV-T2. |

## KPI nhập bằng form

[File để copy](copy/kpi.txt)

| Trường | Giá trị |
| --- | --- |
| Mã KPI | UI-T2-R01-KPI-FORM-01 |
| Tên mục tiêu | UI-T2-R01-KPI-FORM-01 / Hoàn thiện bài báo thử |
| Đơn vị đo | bài |
| Bắt đầu kỳ | 2026-01-01 |
| Kết thúc kỳ | 2026-12-31 |
| Chỉ tiêu số lượng | 2 |
| Kế hoạch thực hiện | Chuẩn bị bản thảo, thu thập tài liệu và đối soát hai hồ sơ giả lập. |
| Căn cứ / Nguồn cung cấp | DỮ LIỆU MÔ PHỎNG do người dùng nhập |
| Kết quả thực tế | 1 |
| Căn cứ kết quả | Kết quả nhập tay cho kiểm thử UI |
| Ghi chú minh chứng kết quả | Có một bộ hồ sơ mô phỏng để kiểm chuyển từ KPI sang thành tích nháp. |

## Văn bản, phiên bản và tiêu chí mô phỏng

[File để copy](copy/regulation.txt)

| Trường | Giá trị |
| --- | --- |
| Mã văn bản | UI-T2-R01-REG-01 |
| Tên văn bản | Quy định thử nghiệm UI - không phải chính sách LHU |
| Loại văn bản | Hướng dẫn / Mô phỏng |
| Cơ quan | Đơn vị mô phỏng PTUD |
| Mô tả | Văn bản giả lập để kiểm tạo phiên bản, trích đoạn và tiêu chí; không có giá trị pháp lý. |
| Phiên bản 1 | v1 |
| Ngày ký | 2026-10-19 |
| Hiệu lực từ | 2026-10-19 |
| Hiệu lực đến | 2026-12-31 |
| Trạng thái nguồn | SIMULATION_ONLY / Mô phỏng |
| Nội dung băm phiên bản 1 | UI-REG-V1. Bản mô phỏng dùng kiểm dữ liệu. Không phải quy định thật. |
| Phiên bản 2 | v2 |
| Hiệu lực từ của v2 | 2027-01-01 |
| Hiệu lực đến của v2 | 2027-12-31 |
| Nội dung băm phiên bản 2 | UI-REG-V2. Bổ sung mô tả và thay đổi nội dung để kiểm hash khác v1. |
| Điều | Điều 1 |
| Khoản | Khoản 1 |
| Trang | 1 |
| Nội dung trích đoạn | Đây là trích đoạn MÔ PHỎNG. Hai hồ sơ nghiên cứu giả lập chỉ phục vụ thao tác kiểm thử và không tạo căn cứ xét thưởng thật. |
| Mã tiêu chí | UI-T2-R01-CRIT-01 |
| Tên tiêu chí | Hai hồ sơ nghiên cứu mô phỏng cho test UI |
| Đối tượng | Cá nhân |
| Ngưỡng tối thiểu | 2 |
| Đơn vị đo tiêu chí | hồ sơ |
| Tham chiếu | Điều 1, Khoản 1, Trang 1 của nguồn mô phỏng |
| Nhãn nguồn không được chọn giả | Không gắn CONFIRMED_LHU_POLICY cho tài liệu này. |

## AI: dữ liệu có thể dùng và điều kiện còn thiếu

[File để copy](copy/ai.txt)

| Trường | Giá trị |
| --- | --- |
| Tài khoản | an.nv hoặc cuong.lh theo chủ thể |
| Tiêu chí có sẵn | SCN-CRIT-01 |
| Tiêu chí không được coi hợp lệ | SCN-CRIT-DRAFT |
| Ngày đánh giá | 2026-10-19 |
| Nguồn hiện tại | SIMULATION_ONLY |
| Kết quả mong đợi của demo | Đọc được lịch sử/thẩm định quy tắc; kết quả cần người có thẩm quyền rà soát. |
| RAG live | Chưa có nguồn quy chế chính thức được phê duyệt trong bộ này. Không tạo tài liệu giả để vượt gate; ghi Bị chặn nếu chưa được cung cấp nguồn hợp lệ. |
| Dữ liệu gửi provider | Chỉ gửi khi phạm vi gửi đã được xác nhận; không nhập API key/token vào form hay bug log. |

## KPI nguồn mô phỏng

[File để copy](copy/external.txt)

| Trường | Giá trị |
| --- | --- |
| Mã nhân viên nguồn | SIM-EMP-001 |
| Ánh xạ tới | Nguyễn Văn An / GV00234 |
| Nguồn | KPI MÔ PHỎNG, không phải tích hợp dữ liệu thật |
| Điều kiện | Người phụ trách môi trường cấu hình mock source riêng cho ENV-T2 trước khi test; không copy một token thật vào tài liệu. |

## Tài khoản / role / phạm vi thử

[File để copy](copy/admin.txt)

| Trường | Giá trị |
| --- | --- |
| Username mới | ui.t2.r01.user |
| Email | ui.t2.r01.user@example.invalid |
| Tên hiển thị | Người dùng thử nghiệm T2 |
| Mật khẩu ban đầu | UiT2@Demo2026 |
| Vai trò để kiểm quyền | Quản lý đơn vị (MANAGER) |
| Đơn vị phạm vi | Khoa Công nghệ Thông tin |
| Bao gồm đơn vị con | Có |
| Hiệu lực từ | 2026-10-19T08:00 |
| Hiệu lực đến | 2027-10-19T23:59 |
| Trạng thái thử khóa | LOCKED |
| Trạng thái khôi phục | ACTIVE |

## Đơn vị / đại diện / điều chuyển

[File để copy](copy/organization.txt)

| Trường | Giá trị |
| --- | --- |
| Mã đơn vị mới | UI-T2-R01-UNIT |
| Tên đơn vị | Bộ môn thử nghiệm UI người 2 |
| Loại | Bộ môn / DEPARTMENT |
| Đơn vị cha | Khoa Công nghệ Thông tin |
| Tài khoản đại diện tự tạo | ui.t2.r01.rep |
| Email đại diện | ui.t2.r01.rep@example.invalid |
| Tên hiển thị đại diện | Đại diện thử nghiệm T2 |
| Mật khẩu đại diện | UiT2@Demo2026 |
| Role gán trước | Đại diện đơn vị / UNIT_REPRESENTATIVE |
| Hạn đại diện | 2027-10-19 |
| Giảng viên chỉ điều chuyển ở cuối lượt | Giảng viên Linh DEMO / linh.pharm |
| Lưu ý | Không điều chuyển An/Bích/Cường. Kiểm sai quyền và baseline báo cáo trước khi chuyển Linh. |

## Danh mục và năm học dùng riêng

[File để copy](copy/catalog.txt)

| Trường | Giá trị |
| --- | --- |
| Mã loại thành tích | RESEARCH_UI_T2_R01 |
| Tên loại thành tích | Nghiên cứu mô phỏng riêng T2 |
| Đối tượng thành tích | LECTURER / Cá nhân |
| Mã loại thưởng | UI_T2_R01_AWARD |
| Tên loại thưởng | Danh hiệu mô phỏng T2 |
| Nhóm loại thưởng | TITLE / Danh hiệu |
| Cấp thưởng | UNIVERSITY / Trường |
| Đối tượng thưởng | LECTURER / Cá nhân |
| Mã năm học | UI-T2-27 |
| Tên năm học | Năm học mô phỏng 2027-2028 |
| Ngày bắt đầu năm học | 2027-09-01 |
| Ngày kết thúc năm học | 2028-08-31 |
| Năm hiện tại khi tạo | Không; ca đổi năm hiện tại chạy cuối và khôi phục baseline 2026-2027. |

## Nội dung dài có tiếng Việt để kiểm UX

[File để copy](copy/long.txt)

| Trường | Giá trị |
| --- | --- |
| Tiêu đề | UI-T2-R01-UX-LONG / Nghiên cứu mô phỏng với nội dung tiếng Việt có dấu, dùng kiểm hiển thị trên màn hình điện thoại và khi phóng to giao diện |
| Mô tả nhiều dòng | Dòng 1: Tiếng Việt có dấu — Nguyễn, Trần, Đặng, nghiên cứu và giảng dạy. / Dòng 2: Chuỗi dài dùng kiểm xuống dòng, không được đè lên nút đóng hoặc nút lưu. Dòng 1: Tiếng Việt có dấu — Nguyễn, Trần, Đặng, nghiên cứu và giảng dạy. / Dòng 2: Chuỗi dài dùng kiểm xuống dòng, không được đè lên nút đóng hoặc nút lưu. Dòng 1: Tiếng Việt có dấu — Nguyễn, Trần, Đặng, nghiên cứu và giảng dạy. / Dòng 2: Chuỗi dài dùng kiểm xuống dòng, không được đè lên nút đóng hoặc nút lưu. Dòng 1: Tiếng Việt có dấu — Nguyễn, Trần, Đặng, nghiên cứu và giảng dạy. / Dòng 2: Chuỗi dài dùng kiểm xuống dòng, không được đè lên nút đóng hoặc nút lưu. Dòng 1: Tiếng Việt có dấu — Nguyễn, Trần, Đặng, nghiên cứu và giảng dạy. / Dòng 2: Chuỗi dài dùng kiểm xuống dòng, không được đè lên nút đóng hoặc nút lưu. Dòng 1: Tiếng Việt có dấu — Nguyễn, Trần, Đặng, nghiên cứu và giảng dạy. / Dòng 2: Chuỗi dài dùng kiểm xuống dòng, không được đè lên nút đóng hoặc nút lưu. Dòng 1: Tiếng Việt có dấu — Nguyễn, Trần, Đặng, nghiên cứu và giảng dạy. / Dòng 2: Chuỗi dài dùng kiểm xuống dòng, không được đè lên nút đóng hoặc nút lưu. Dòng 1: Tiếng Việt có dấu — Nguyễn, Trần, Đặng, nghiên cứu và giảng dạy. / Dòng 2: Chuỗi dài dùng kiểm xuống dòng, không được đè lên nút đóng hoặc nút lưu.  |
| Tên file dài | uploads/valid/minh-chung-ten-tep-rat-dai-co-tieng-viet-de-kiem-xuong-dong-tren-dien-thoai.pdf |

