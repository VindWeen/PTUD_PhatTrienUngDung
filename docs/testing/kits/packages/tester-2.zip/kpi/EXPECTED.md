# Kết quả mong đợi của file nhập KPI

- import-valid.csv / .tsv / .xlsx: mỗi file 3 dòng hợp lệ, mã khác nhau giữa định dạng để có thể nhập cả ba trên cùng ENV-T2. Cột actual/evidenceNote giữ nguyên 10 cột.
- import-invalid.csv / .xlsx: dòng 2 đảo ngày, dòng 3 có chỉ tiêu âm; preview phải báo lỗi.
- import-missing-column.csv: cố ý thiếu header sourceNote, bị chặn đọc cấu trúc.
- import-duplicate-code.csv: mã dòng 2 và 3 giống nhau; ghi đúng thông báo trùng thực tế, không mặc định tự gộp.
- import-corrupt.xlsx: sai cấu trúc XLSX, phải báo lỗi đọc.
- import-over-5mb.csv: lớn hơn 5 MB, phải bị chặn kích thước trước khi nhập.

File XLSX ở đây là đầu vào upload, không phải bản Excel của test plan. Không sửa tên header, thêm dòng tiêu đề hoặc thêm sheet giải thích vào file nhập.
