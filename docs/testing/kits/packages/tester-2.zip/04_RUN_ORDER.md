# Thứ tự dùng bộ dữ liệu người 2

| Chặng | Ca | Mẫu trong copy/ | Cách dùng |
| --- | --- | --- | --- |
| 01 | AUTH | auth, password | Trước giờ test, chạy seed bổ sung ui.t2.password trên ENV-T2. Dùng riêng tài khoản này cho AUTH-07. |
| 02 | REP-01…05; đọc AI/REG | ai | Đối chiếu baseline trước khi sửa/thu hồi. Có R02 và RT01 sẵn, không đợi luồng người 1. |
| 03 | ACH | achievement, collective, reasons | Dùng các A02/A03/A05…A10/T01/T02 theo ca; nháp mới dùng prefix T2. |
| 04 | KPI; REG/AI ghi | kpi, regulation, ai, external | File nhập trong kpi/. Preview trước khi ghi; AI thiếu nguồn chính thức ghi Bị chặn, không xác nhận văn bản giả. |
| 05 | REP-06 | report-revoke, reasons | Tự tạo quyết định/sổ REPORT-REVOKE; ghi số trước → tự thu hồi → so báo cáo, không dùng sổ của người 1. |
| 06 | UX | long, double, consistency | Tự dựng DOUBLE và CONSISTENCY qua UI trước ca tương ứng; không dùng người 1 để tạo hộ. |
| 07 | ORG/ADM | organization, admin, catalog | Chạy cuối; điều chuyển Linh sau ca baseline. Không khóa tài khoản An/Bích/Cường hoặc sửa nguồn seed. |

Mỗi chặng tự làm bằng các role riêng trong môi trường của mình; không có bước bàn giao cho tester khác. Khi thiếu điều kiện hoặc UI lỗi, ghi Bị chặn/Lỗi rồi chuyển ca độc lập.
