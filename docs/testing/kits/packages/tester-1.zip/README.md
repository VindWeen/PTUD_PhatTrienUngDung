# Bộ chuẩn bị người test 1

**Bắt đầu:** mở [Thứ tự chạy](04_RUN_ORDER.md), sau đó [Test plan của mình](01_TEST_PLAN.md).

- [Dữ liệu copy theo từng form](02_COPY_DATA.md), hoặc mở từng tệp .txt trong copy/.
- [Tra đúng file/dữ liệu theo từng ID ca](03_FILES_BY_CASE.md) — đủ 72 ca.
- [Baseline ban đầu](05_BASELINE.md), [file hợp lệ/lỗi](06_UPLOAD_EXPECTATIONS.md), [mẫu ghi bug](07_BUG_TEMPLATE.md).

Mọi tên/tài liệu là dữ liệu MÔ PHỎNG. File cố ý hỏng nằm riêng trong uploads/invalid/. Không đổi cấu hình hoặc reset database khi đang test.

Bộ này không tự chạy test, không tự ghi dữ liệu, không chứa key/token thật. Hai người vẫn cần ENV-T1/ENV-T2 riêng đã nạp SCN. File Excel là dữ liệu đầu vào upload KPI; chưa xuất test plan thành Excel. Ngày ví dụ: 19/10/2026. Nếu chạy ngày khác, chỉnh ngày lịch/quyết định/hiệu lực cho phù hợp và chọn đúng kỳ seed đang mở.
