# Thứ tự dùng bộ dữ liệu người 1

| Chặng | Ca | Mẫu trong copy/ | Cách dùng |
| --- | --- | --- | --- |
| 01 | AUTH/HOME | auth, profile | Kiểm phiên và điều hướng; không cần tạo hồ sơ trước. |
| 02 | FLOW-01…15 | main, reasons | Dùng SCN-A01. Tự đổi An → Bích → council.demo → records.demo → An/Bích. File v1 khi nộp, v2 khi bổ sung, decision-demo khi ghi nhận. |
| 03 | APP/AWD | proposal, collective, decision, revocation, reasons | Dùng P01…P07/PT01 và R01…R03; không thu hồi quyết định MAIN. |
| 04 | CAL | calendar-* | Tạo lịch bằng mẫu; quá hạn dùng mẫu overdue. Lịch không được seed sẵn để không bỏ qua ca tạo. |
| 05 | PORT | portfolio-paper-1…5, portfolio-patent, portfolio-teaching | Tự tạo 5 bài báo + 1 sáng chế + 1 giáo trình qua UI. An seed có 8 hồ sơ nghiên cứu nên đủ ít nhất 14 hồ sơ nhóm nghiên cứu, đồng thời có dữ liệu nhóm Giảng dạy. Không upload các mẫu này như import thành tích vì UI chưa có chức năng đó. |
| 06 | NOTI | main, reasons | Thông báo sinh ra từ flow của chính mình; không chờ người 2. |

Mỗi chặng tự làm bằng các role riêng trong môi trường của mình; không có bước bàn giao cho tester khác. Khi thiếu điều kiện hoặc UI lỗi, ghi Bị chặn/Lỗi rồi chuyển ca độc lập.
