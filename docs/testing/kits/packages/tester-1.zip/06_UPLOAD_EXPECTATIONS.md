# Chọn file đúng mục đích

| File | Mong đợi |
| --- | --- |
| uploads/valid/evidence-v1.pdf | PDF minh chứng ban đầu, tải về mở được |
| uploads/valid/evidence-v2.pdf | Nội dung và SHA khác v1, dùng khi tải phiên bản mới |
| uploads/valid/decision-demo.pdf | File quyết định mô phỏng cho sổ thưởng |
| uploads/valid/evidence-image.png / .jpg | Ảnh hợp lệ nếu muốn kiểm thêm định dạng ảnh |
| uploads/invalid/empty.pdf | 0 byte, phải bị từ chối |
| uploads/invalid/not-supported.txt | Sai định dạng minh chứng |
| uploads/invalid/fake-pdf.pdf | Nội dung văn bản nhưng đổi đuôi PDF, phải bị từ chối |
| uploads/invalid/over-10mb.pdf | 10 MB + 1 byte, phải bị chặn kích thước |

V2 là thêm phiên bản của minh chứng cũ khi UI có chức năng; không nhầm tạo một minh chứng mới rồi kết luận đã test lịch sử phiên bản. Link file private chỉ kiểm bằng URL thực tế lấy được từ UI. Nếu UI chỉ tạo blob: mà không cung cấp đường dẫn tải có thể kiểm, ghi giới hạn ca NOTI-03/04, không tự dựng API URL để thay thế kiểm thử UI.
