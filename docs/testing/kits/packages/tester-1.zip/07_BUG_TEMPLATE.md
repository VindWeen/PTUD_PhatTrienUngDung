# Bug log người 1

Mã: BUG-T1-001
Môi trường: ENV-T1
Ca liên quan:
Tài khoản / trạng thái trước:
Các bước tái hiện:
1.
2.
Mong đợi:
Thực tế:
Ảnh/video/file:
Mức độ:
Ngày / người test:
Kết quả test lại:
