# Dữ liệu mẫu để copy theo form

Ngày mẫu 19/10/2026. Nếu test ngày khác: đổi ngày quyết định và lịch thành ngày phù hợp; giữ thứ tự thời gian và nhãn mô phỏng. Kỳ SCN chọn theo ngày seed thực tế.

## Thông tin khi thêm minh chứng / phiên bản

[File để copy](copy/evidence.txt)

| Trường | Giá trị |
| --- | --- |
| Tên minh chứng ban đầu | UI-T1-R01-EVIDENCE / Minh chứng mô phỏng V1 |
| Mô tả | Tệp mô phỏng dùng kiểm upload, tải về và lịch sử phiên bản. |
| File ban đầu | uploads/valid/evidence-v1.pdf |
| Ghi chú phiên bản mới | V2: bổ sung nội dung để đối chiếu; khác nội dung và SHA của V1. |
| File phiên bản mới | uploads/valid/evidence-v2.pdf |

## Đăng nhập và chuyển vai trò

[File để copy](copy/auth.txt)

| Trường | Giá trị |
| --- | --- |
| Mật khẩu 10 tài khoản SCN | demo1234 |
| Tài khoản dùng | an.nv / bich.tt / duc.pm / cuong.lh / records.demo / council.demo / council.other / linh.pharm / rep.expired / locked.demo |
| Mật khẩu sai để thử | Wrong@2026 |
| Tài khoản không tồn tại | not.exists.t1 |
| Lưu ý | locked.demo cố ý bị khóa; rep.expired có role nhưng phân công đã hết hạn. Chuyển role bằng đăng xuất hoặc profile trình duyệt riêng. |

## Nháp thành tích dùng riêng

[File để copy](copy/achievement.txt)

| Trường | Giá trị |
| --- | --- |
| Tên thành tích | UI-T1-R01-ACH-01 / Hồ sơ thử nghiệm cá nhân [MÔ PHỎNG] |
| Chủ thể | Cá nhân / Nguyễn Văn An |
| Loại thành tích | Bài báo quốc tế ISI/Scopus Q1 |
| Mô tả | Dữ liệu thử nghiệm giao diện. Chỉ dùng kiểm luồng kê khai, minh chứng và xét duyệt; không xác nhận thành tích thực tế. |
| Vai trò đóng góp | Tác giả chính |
| Ngày bắt đầu | 2026-09-29 |
| Ngày kết thúc | 2026-10-14 |
| Năm ghi nhận | 2026 |
| Năm học | 2026-2027 |
| File chọn | uploads/valid/evidence-v1.pdf |

## Ý kiến và lý do mẫu

[File để copy](copy/reasons.txt)

| Trường | Giá trị |
| --- | --- |
| Yêu cầu bổ sung | Bổ sung vai trò đóng góp và tải lại minh chứng có nội dung phiên bản V2 để đối chiếu. |
| Nội dung bổ sung | Đã bổ sung vai trò tác giả chính, tổng hợp dữ liệu và kiểm tra kết quả. Minh chứng V2 được đính kèm. |
| Xác nhận thành tích | Đã kiểm tra nội dung và minh chứng của hồ sơ mô phỏng, thông tin khớp với dữ liệu thử nghiệm. |
| Từ chối | Minh chứng thử nghiệm không khớp nội dung kê khai trong ca kiểm nhánh từ chối. |
| Rút/hủy | Chủ hồ sơ rút kê khai để kiểm tra lịch sử và trạng thái hủy. |
| Thu hồi | Phát hiện sai nội dung trong hồ sơ mô phỏng; thu hồi để kiểm tra báo cáo và bản thay thế. |
| Chuyển Hội đồng | Đơn vị đã đối chiếu thành tích nguồn và minh chứng. Chuyển Hội đồng rà soát hồ sơ mô phỏng. |
| Phân công | Phân công council.demo xử lý hồ sơ mô phỏng trong phạm vi CNTT. |
| Ghi ý kiến Hội đồng | Hồ sơ mô phỏng có nguồn và minh chứng đọc được; cần đối chiếu tiêu chí áp dụng trước kết luận. |
| Đề nghị | Đề nghị xử lý khen thưởng trong kịch bản thử nghiệm; chưa phải quyết định trao thưởng. |
| Không đề nghị | Chưa đáp ứng yêu cầu của nhánh kiểm thử; lưu lý do không đề nghị. |
| File bổ sung | uploads/valid/evidence-v2.pdf |

## Đề nghị cá nhân mới

[File để copy](copy/proposal.txt)

| Trường | Giá trị |
| --- | --- |
| Chủ thể | Cá nhân / Nguyễn Văn An |
| Kỳ xét | SCN / Kỳ xét thưởng đang mở - MÔ PHỎNG (SCN-OPEN-2026) |
| Loại khen thưởng | Chiến sĩ thi đua cơ sở |
| Thành tích chọn | SCN-A04 |
| Mục đích đề nghị | UI-T1-R01-APP-NEW / Đề nghị xét khen thưởng MÔ PHỎNG để kiểm thử UI. |
| Lưu ý | Chọn hồ sơ bằng tên; chỉ dùng nguồn đã xác nhận của đúng chủ thể. |

## Đề nghị / thành tích tập thể

[File để copy](copy/collective.txt)

| Trường | Giá trị |
| --- | --- |
| Chủ thể | Tập thể / Bộ môn Kỹ thuật Phần mềm |
| Kỳ xét | SCN / Kỳ xét thưởng đang mở - MÔ PHỎNG (SCN-OPEN-2026) |
| Loại khen thưởng | Tập thể Lao động xuất sắc |
| Thành tích chọn | SCN-T02 |
| Mục đích đề nghị | UI-T1-R01-APP-UNIT / Đề nghị xét khen thưởng MÔ PHỎNG để kiểm thử UI. |
| Lưu ý | Chọn hồ sơ bằng tên; chỉ dùng nguồn đã xác nhận của đúng chủ thể. |
| Tài khoản kê khai | cuong.lh |
| Tên thành tích nếu cần tự tạo | UI-T1-R01-UNIT-ACH / Sáng chế tập thể mô phỏng |
| Loại thành tích | Bằng độc quyền sáng chế |
| Lưu ý phạm vi | Cường đại diện KTPM, không phải KHMT hoặc toàn Khoa CNTT. |

## Quyết định và sổ riêng

[File để copy](copy/decision.txt)

| Trường | Giá trị |
| --- | --- |
| Số quyết định | UI-T1-R01-AWD-NEW-2026 |
| Ngày quyết định | 2026-10-19 |
| Cơ quan ban hành | Đơn vị mô phỏng PTUD |
| Tên quyết định | UI-T1-R01-AWD-NEW / Quyết định thử nghiệm, không có giá trị thực tế |
| Chủ thể ghi sổ | Cá nhân / Nguyễn Văn An |
| Loại khen thưởng | Chiến sĩ thi đua cơ sở |
| Năm ghi nhận | 2026 |
| Nguồn chọn | SCN-A04 (hoặc thành tích riêng đã xác nhận của ca) |
| File quyết định | uploads/valid/decision-demo.pdf |

## Thông tin hồ sơ mẫu

[File để copy](copy/profile.txt)

| Trường | Giá trị |
| --- | --- |
| Số điện thoại | 0900000001 |
| Chức danh | Giảng viên thử nghiệm |
| Học vị | Thạc sĩ |
| Lưu ý | Thông tin giả lập để kiểm lưu; không đổi đơn vị hoặc quyền ở form hồ sơ. |

## Luồng MAIN - A01 đến sổ thưởng

[File để copy](copy/main.txt)

| Trường | Giá trị |
| --- | --- |
| Chủ thể | Cá nhân / Nguyễn Văn An |
| Kỳ xét | SCN / Kỳ xét thưởng đang mở - MÔ PHỎNG (SCN-OPEN-2026) |
| Loại khen thưởng | Chiến sĩ thi đua cơ sở |
| Thành tích chọn | SCN-A01 sau khi chính người 1 xác nhận qua FLOW-01…05 |
| Mục đích đề nghị | UI-T1-R01-MAIN / Đề nghị cá nhân MÔ PHỎNG |
| Lưu ý | Chọn hồ sơ bằng tên; chỉ dùng nguồn đã xác nhận của đúng chủ thể. |
| Số quyết định | UI-T1-R01-MAIN-2026 |
| Ngày quyết định | 2026-10-19 |
| Cơ quan ban hành | Đơn vị mô phỏng PTUD |
| File lần đầu | uploads/valid/evidence-v1.pdf |
| File bổ sung | uploads/valid/evidence-v2.pdf |
| File quyết định | uploads/valid/decision-demo.pdf |
| Người xét chọn | council.demo |

## Sổ riêng để thu hồi, không dùng MAIN

[File để copy](copy/revocation.txt)

| Trường | Giá trị |
| --- | --- |
| Số quyết định | UI-T1-R01-AWD-REVOKE-2026 |
| Ngày quyết định | 2026-10-19 |
| Cơ quan ban hành | Đơn vị mô phỏng PTUD |
| Tên quyết định | UI-T1-R01-AWD-REVOKE / Quyết định thử nghiệm, không có giá trị thực tế |
| Chủ thể ghi sổ | Cá nhân / Nguyễn Văn An |
| Loại khen thưởng | Chiến sĩ thi đua cơ sở |
| Năm ghi nhận | 2026 |
| Nguồn chọn | SCN-A04 (hoặc thành tích riêng đã xác nhận của ca) |
| File quyết định | uploads/valid/decision-demo.pdf |

## Nháp phân trang 1/5

[File để copy](copy/portfolio-paper-1.txt)

| Trường | Giá trị |
| --- | --- |
| Tên thành tích | UI-T1-R01-PORT-PAPER-01 / Bài báo phân trang số 1 [MÔ PHỎNG] |
| Chủ thể | Cá nhân / Nguyễn Văn An |
| Loại thành tích | Bài báo quốc tế ISI/Scopus Q1 |
| Mô tả | Dữ liệu thử nghiệm giao diện. Chỉ dùng kiểm luồng kê khai, minh chứng và xét duyệt; không xác nhận thành tích thực tế. |
| Vai trò đóng góp | Tác giả chính |
| Ngày bắt đầu | 2026-09-29 |
| Ngày kết thúc | 2026-10-14 |
| Năm ghi nhận | 2026 |
| Năm học | 2026-2027 |
| File chọn | uploads/valid/evidence-v1.pdf |

## Nháp phân trang 2/5

[File để copy](copy/portfolio-paper-2.txt)

| Trường | Giá trị |
| --- | --- |
| Tên thành tích | UI-T1-R01-PORT-PAPER-02 / Bài báo phân trang số 2 [MÔ PHỎNG] |
| Chủ thể | Cá nhân / Nguyễn Văn An |
| Loại thành tích | Bài báo quốc tế ISI/Scopus Q1 |
| Mô tả | Dữ liệu thử nghiệm giao diện. Chỉ dùng kiểm luồng kê khai, minh chứng và xét duyệt; không xác nhận thành tích thực tế. |
| Vai trò đóng góp | Tác giả chính |
| Ngày bắt đầu | 2026-09-29 |
| Ngày kết thúc | 2026-10-14 |
| Năm ghi nhận | 2026 |
| Năm học | 2026-2027 |
| File chọn | uploads/valid/evidence-v1.pdf |

## Nháp phân trang 3/5

[File để copy](copy/portfolio-paper-3.txt)

| Trường | Giá trị |
| --- | --- |
| Tên thành tích | UI-T1-R01-PORT-PAPER-03 / Bài báo phân trang số 3 [MÔ PHỎNG] |
| Chủ thể | Cá nhân / Nguyễn Văn An |
| Loại thành tích | Bài báo quốc tế ISI/Scopus Q1 |
| Mô tả | Dữ liệu thử nghiệm giao diện. Chỉ dùng kiểm luồng kê khai, minh chứng và xét duyệt; không xác nhận thành tích thực tế. |
| Vai trò đóng góp | Tác giả chính |
| Ngày bắt đầu | 2026-09-29 |
| Ngày kết thúc | 2026-10-14 |
| Năm ghi nhận | 2026 |
| Năm học | 2026-2027 |
| File chọn | uploads/valid/evidence-v1.pdf |

## Nháp phân trang 4/5

[File để copy](copy/portfolio-paper-4.txt)

| Trường | Giá trị |
| --- | --- |
| Tên thành tích | UI-T1-R01-PORT-PAPER-04 / Bài báo phân trang số 4 [MÔ PHỎNG] |
| Chủ thể | Cá nhân / Nguyễn Văn An |
| Loại thành tích | Bài báo quốc tế ISI/Scopus Q1 |
| Mô tả | Dữ liệu thử nghiệm giao diện. Chỉ dùng kiểm luồng kê khai, minh chứng và xét duyệt; không xác nhận thành tích thực tế. |
| Vai trò đóng góp | Tác giả chính |
| Ngày bắt đầu | 2026-09-29 |
| Ngày kết thúc | 2026-10-14 |
| Năm ghi nhận | 2026 |
| Năm học | 2026-2027 |
| File chọn | uploads/valid/evidence-v1.pdf |

## Nháp phân trang 5/5

[File để copy](copy/portfolio-paper-5.txt)

| Trường | Giá trị |
| --- | --- |
| Tên thành tích | UI-T1-R01-PORT-PAPER-05 / Bài báo phân trang số 5 [MÔ PHỎNG] |
| Chủ thể | Cá nhân / Nguyễn Văn An |
| Loại thành tích | Bài báo quốc tế ISI/Scopus Q1 |
| Mô tả | Dữ liệu thử nghiệm giao diện. Chỉ dùng kiểm luồng kê khai, minh chứng và xét duyệt; không xác nhận thành tích thực tế. |
| Vai trò đóng góp | Tác giả chính |
| Ngày bắt đầu | 2026-09-29 |
| Ngày kết thúc | 2026-10-14 |
| Năm ghi nhận | 2026 |
| Năm học | 2026-2027 |
| File chọn | uploads/valid/evidence-v1.pdf |

## Phân nhóm nghiên cứu - sáng chế

[File để copy](copy/portfolio-patent.txt)

| Trường | Giá trị |
| --- | --- |
| Tên thành tích | UI-T1-R01-PORT-PATENT / Sáng chế dùng kiểm phân nhóm [MÔ PHỎNG] |
| Chủ thể | Cá nhân / Nguyễn Văn An |
| Loại thành tích | Bằng độc quyền sáng chế |
| Mô tả | Dữ liệu thử nghiệm giao diện. Chỉ dùng kiểm luồng kê khai, minh chứng và xét duyệt; không xác nhận thành tích thực tế. |
| Vai trò đóng góp | Tác giả chính |
| Ngày bắt đầu | 2026-09-29 |
| Ngày kết thúc | 2026-10-14 |
| Năm ghi nhận | 2026 |
| Năm học | 2026-2027 |
| File chọn | uploads/valid/evidence-v1.pdf |

## Phân nhóm giảng dạy - giáo trình

[File để copy](copy/portfolio-teaching.txt)

| Trường | Giá trị |
| --- | --- |
| Tên thành tích | UI-T1-R01-PORT-TEACHING / Giáo trình dùng kiểm phân nhóm [MÔ PHỎNG] |
| Chủ thể | Cá nhân / Nguyễn Văn An |
| Loại thành tích | Giáo trình được nghiệm thu |
| Mô tả | Dữ liệu thử nghiệm giao diện. Chỉ dùng kiểm luồng kê khai, minh chứng và xét duyệt; không xác nhận thành tích thực tế. |
| Vai trò đóng góp | Tác giả chính |
| Ngày bắt đầu | 2026-09-29 |
| Ngày kết thúc | 2026-10-14 |
| Năm ghi nhận | 2026 |
| Năm học | 2026-2027 |
| File chọn | uploads/valid/evidence-v1.pdf |

## Nháp riêng thử đóng form / file lỗi

[File để copy](copy/portfolio-upload.txt)

| Trường | Giá trị |
| --- | --- |
| Tên thành tích | UI-T1-R01-PORT-UPLOAD / Hồ sơ riêng kiểm popup upload [MÔ PHỎNG] |
| Chủ thể | Cá nhân / Nguyễn Văn An |
| Loại thành tích | Bài báo quốc tế ISI/Scopus Q1 |
| Mô tả | Dữ liệu thử nghiệm giao diện. Chỉ dùng kiểm luồng kê khai, minh chứng và xét duyệt; không xác nhận thành tích thực tế. |
| Vai trò đóng góp | Tác giả chính |
| Ngày bắt đầu | 2026-09-29 |
| Ngày kết thúc | 2026-10-14 |
| Năm ghi nhận | 2026 |
| Năm học | 2026-2027 |
| File chọn | uploads/valid/evidence-v1.pdf |

## Lịch thi thử

[File để copy](copy/calendar-exam.txt)

| Trường | Giá trị |
| --- | --- |
| Tiêu đề | UI-T1-R01-Lịch thi thử |
| Loại | Lịch thi |
| Bắt đầu | 2026-10-20T08:00 |
| Kết thúc | 2026-10-20T10:00 |
| Cả ngày | Không |
| Địa điểm / đường dẫn | Phòng thực hành mô phỏng |
| Ghi chú | Ghi chú kiểm thử có tiếng Việt. / Dòng thứ hai để kiểm xuống dòng. |
| Hoàn thành | Chưa |

## Cuộc thi nghiên cứu thử

[File để copy](copy/calendar-competition.txt)

| Trường | Giá trị |
| --- | --- |
| Tiêu đề | UI-T1-R01-Cuộc thi nghiên cứu thử |
| Loại | Cuộc thi |
| Bắt đầu | 2026-10-21T09:00 |
| Kết thúc | 2026-10-21T11:00 |
| Cả ngày | Không |
| Địa điểm / đường dẫn | Phòng thực hành mô phỏng |
| Ghi chú | Ghi chú kiểm thử có tiếng Việt. / Dòng thứ hai để kiểm xuống dòng. |
| Hoàn thành | Chưa |

## Hoàn thiện hồ sơ thử

[File để copy](copy/calendar-task.txt)

| Trường | Giá trị |
| --- | --- |
| Tiêu đề | UI-T1-R01-Hoàn thiện hồ sơ thử |
| Loại | Công việc |
| Bắt đầu | 2026-10-22T13:30 |
| Kết thúc | 2026-10-22T15:00 |
| Cả ngày | Không |
| Địa điểm / đường dẫn | Phòng thực hành mô phỏng |
| Ghi chú | Ghi chú kiểm thử có tiếng Việt. / Dòng thứ hai để kiểm xuống dòng. |
| Hoàn thành | Chưa |

## Ghi chú cá nhân thử

[File để copy](copy/calendar-personal.txt)

| Trường | Giá trị |
| --- | --- |
| Tiêu đề | UI-T1-R01-Ghi chú cá nhân thử |
| Loại | Cá nhân |
| Bắt đầu | 2026-10-20T17:00 |
| Kết thúc | 2026-10-20T17:30 |
| Cả ngày | Không |
| Địa điểm / đường dẫn | Phòng thực hành mô phỏng |
| Ghi chú | Ghi chú kiểm thử có tiếng Việt. / Dòng thứ hai để kiểm xuống dòng. |
| Hoàn thành | Chưa |

## Việc quá hạn mô phỏng

[File để copy](copy/calendar-overdue.txt)

| Trường | Giá trị |
| --- | --- |
| Tiêu đề | UI-T1-R01-Việc quá hạn mô phỏng |
| Loại | Công việc |
| Bắt đầu | 2026-10-17T08:00 |
| Kết thúc | 2026-10-17T09:00 |
| Cả ngày | Không |
| Địa điểm / đường dẫn | Phòng thực hành mô phỏng |
| Ghi chú | Ghi chú kiểm thử có tiếng Việt. / Dòng thứ hai để kiểm xuống dòng. |
| Hoàn thành | Chưa |

## Lịch cả ngày qua tháng

[File để copy](copy/calendar-multiday.txt)

| Trường | Giá trị |
| --- | --- |
| Tiêu đề | UI-T1-R01-CAL-MULTIDAY |
| Loại | Cá nhân |
| Cả ngày | Có |
| Bắt đầu | 2026-10-31 |
| Kết thúc | 2026-11-02 |
| Ghi chú | Phải hiển thị đủ ngày 31/10, 01/11 và 02/11. |

## Lịch sai để kiểm chặn

[File để copy](copy/calendar-invalid.txt)

| Trường | Giá trị |
| --- | --- |
| Tiêu đề | UI-T1-R01-CAL-BAD |
| Bắt đầu | 2026-10-20T10:00 |
| Kết thúc | 2026-10-20T09:00 |
| Mong đợi | Bị chặn; không tạo bản ghi. |

