# Seed ban đầu và dữ liệu phải tạo qua UI

SCN-A01 nháp thiếu file; A02 chờ duyệt; A03 cần bổ sung; A04 xác nhận; A05 từ chối; A06 hủy; A07 thu hồi; A08 nháp thay A07; A09 của Bích; A10 của Linh; T01 nháp tập thể; T02 tập thể đã xác nhận. P01…P07 và PT01 là đề nghị nhiều trạng thái. R01 thiếu file, R02 ghi nhận, R03 thu hồi, RT01 tập thể. K01/K02/K03/KT01 là KPI seed.

Trước khi test, SCN chuẩn có 10 tài khoản, 12 thành tích, 8 đề nghị, 4 sổ thưởng, 4 KPI, 2 phiên AI mô phỏng. ENV-T1 không cần tài khoản bổ sung.

Lịch ban đầu trống. Dữ liệu phân trang, lịch, nhập KPI, hồ sơ DOUBLE/CONSISTENCY và tài khoản quản trị mới được tạo lúc test bằng UI theo mẫu. Chúng không được tự import vào database để tránh bỏ qua ca tạo dữ liệu.

Bản database hiện tại có thể có thêm phiên AI từ lượt kiểm tra trước. Người phụ trách ghi đúng ngày seed/baseline của từng môi trường; không coi hiện tại đã có hai môi trường sẵn sàng.
